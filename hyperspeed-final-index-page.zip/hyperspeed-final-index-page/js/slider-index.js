document.addEventListener('DOMContentLoaded', () => {
    const servicesSliderSection = document.querySelector('#services.services-section.dark-section');
    if (!servicesSliderSection) return;

    const sliderWrapper = servicesSliderSection.querySelector('.services-slider-wrapper');
    const itemsGrid = servicesSliderSection.querySelector('#services-slider-items');
    const serviceCards = Array.from(servicesSliderSection.querySelectorAll('.service-card'));
    const prevButton = servicesSliderSection.querySelector('#services-slider-prev');
    const nextButton = servicesSliderSection.querySelector('#services-slider-next');

    if (!sliderWrapper || !itemsGrid || serviceCards.length === 0 || !prevButton || !nextButton) {
        console.warn('Services Slider: Missing elements. Functionality disabled.');
        if (prevButton) prevButton.style.display = 'none';
        if (nextButton) nextButton.style.display = 'none';
        return;
    }

    let currentIndex = 0; // Index of the first visible card on the left
    const totalItems = serviceCards.length;
    let itemWidth = 0;    // Width of a single card
    let gap = 0;          // Gap between cards
    let itemsPerView = 1; // How many full items can fit in the wrapper

    function calculateDimensions() {
        if (serviceCards.length === 0) return;

        const firstCard = serviceCards[0];
        itemWidth = firstCard.offsetWidth; // Includes padding, border

        const gridStyle = window.getComputedStyle(itemsGrid);
        gap = parseFloat(gridStyle.gap) || 0;

        const wrapperWidth = sliderWrapper.offsetWidth;

        if ((itemWidth + gap) > 0) {
            // Calculate how many full items + their gaps fit
            itemsPerView = Math.max(1, Math.floor((wrapperWidth + gap) / (itemWidth + gap)));
        } else {
            itemsPerView = 1; // Fallback
        }
        // console.log(`Calc - CardW: ${itemWidth}, Gap: ${gap}, ItemOuterW: ${itemWidth + gap}, WrapW: ${wrapperWidth}, ItemsPerView: ${itemsPerView}`);
    }

    function updateSlider() {
        calculateDimensions(); // Always recalculate before moving

        // maxScrollableIndex is the highest index the *first card on the left* can be
        // to ensure the *last card on the right* is fully visible.
        const maxScrollableIndex = Math.max(0, totalItems - itemsPerView);

        // Clamp currentIndex to prevent overscrolling
        currentIndex = Math.max(0, Math.min(currentIndex, maxScrollableIndex));

        // Calculate the translation
        const translateX = -currentIndex * (itemWidth + gap);
        // console.log(`Slide - Index: ${currentIndex}, TranslateX: ${translateX}px, MaxScrollableIndex: ${maxScrollableIndex}, ItemsPerView: ${itemsPerView}`);
        itemsGrid.style.transform = `translateX(${translateX}px)`;

        // Update button states
        prevButton.disabled = currentIndex === 0;
        nextButton.disabled = currentIndex >= maxScrollableIndex;

        // Hide navigation if all items fit within the viewport
        if (totalItems <= itemsPerView) {
            prevButton.style.display = 'none';
            nextButton.style.display = 'none';
        } else {
            prevButton.style.display = 'flex';
            nextButton.style.display = 'flex';
        }
    }

    nextButton.addEventListener('click', () => {
        calculateDimensions(); // Ensure dimensions are up-to-date
        const maxScrollableIndex = Math.max(0, totalItems - itemsPerView);
        if (currentIndex < maxScrollableIndex) {
            currentIndex++;
            updateSlider();
        }
    });

    prevButton.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    });

    let resizeDebounceTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeDebounceTimeout);
        resizeDebounceTimeout = setTimeout(() => {
            updateSlider(); // Recalculates dimensions and updates position
        }, 250);
    });

    // Initial setup
    if (totalItems > 0) {
        updateSlider();
    } else {
        prevButton.style.display = 'none';
        nextButton.style.display = 'none';
    }
});