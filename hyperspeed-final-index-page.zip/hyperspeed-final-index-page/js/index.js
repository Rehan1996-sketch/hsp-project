document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.getElementById('menu-toggle-button');
    const navWrapper = document.querySelector('.nav-cta-wrapper'); // Element that gets 'mobile-active'
    const mainNav = document.getElementById('main-nav'); // The <nav> element

    if (menuToggle && navWrapper && mainNav) {
        menuToggle.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent click from immediately closing menu via document listener
            toggleMenu();
        });

        const navLinks = mainNav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (navWrapper.classList.contains('mobile-active')) {
                    closeMenu();
                }
            });
        });

        // --- ADDED: Close menu when clicking outside ---
        document.addEventListener('click', function (event) {
            // Check if the menu is open AND the click was outside the nav wrapper AND outside the toggle button
            if (navWrapper.classList.contains('mobile-active') &&
                !navWrapper.contains(event.target) && /* Click is not inside navWrapper */
                event.target !== menuToggle && /* Click is not the toggle button itself */
                !menuToggle.contains(event.target) /* Click is not inside an icon within the toggle button */
                ) {
                closeMenu();
            }
        });

        // Optional: Prevent clicks inside the menu from closing it (if document listener is too broad)
        // This is generally handled by the !navWrapper.contains(event.target) check above
        // navWrapper.addEventListener('click', function (event) {
        //     event.stopPropagation();
        // });
        // --- END ADDED ---

    } else {
        if (!menuToggle) console.error("Menu toggle button ('menu-toggle-button') not found.");
        if (!navWrapper) console.error("Navigation wrapper ('.nav-cta-wrapper') not found.");
        if (!mainNav) console.error("Main navigation ('main-nav') element not found.");
    }

    function toggleMenu() {
        navWrapper.classList.toggle('mobile-active');
        updateMenuButton();
    }

    function closeMenu() {
        navWrapper.classList.remove('mobile-active');
        updateMenuButton();
    }

    function updateMenuButton() {
        const isMenuOpen = navWrapper.classList.contains('mobile-active');
        menuToggle.setAttribute('aria-expanded', isMenuOpen);
        if (isMenuOpen) {
            menuToggle.innerHTML = '<i class="fa-solid fa-times"></i>';
            menuToggle.setAttribute('aria-label', 'Close Menu');
        } else {
            menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
            menuToggle.setAttribute('aria-label', 'Open Menu');
        }
    }

    const siteHeader = document.querySelector('.site-header');
    if (siteHeader) {
        const stickyPoint = 50;
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > stickyPoint) {
                siteHeader.classList.add('scrolled');
            } else {
                siteHeader.classList.remove('scrolled');
            }
        });
    }
});